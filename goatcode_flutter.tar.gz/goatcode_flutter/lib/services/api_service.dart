import 'dart:async';
import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import '../models/models.dart';

class GoatCodeApiService {
  final Dio _dio;
  final String baseUrl;
  WebSocketChannel? _wsChannel;
  
  GoatCodeApiService({
    required this.baseUrl,
  }) : _dio = Dio(BaseOptions(
          baseUrl: baseUrl,
          connectTimeout: const Duration(seconds: 30),
          receiveTimeout: const Duration(seconds: 30),
          headers: {
            'Content-Type': 'application/json',
          },
        ));
  
  // ============================================================
  // Task Management
  // ============================================================
  
  Future<CodeTask> createTask({
    required String projectId,
    required String prompt,
    String testCommand = 'pytest',
    int maxRetries = 5,
  }) async {
    try {
      final response = await _dio.post('/v1/tasks', data: {
        'project_id': projectId,
        'prompt': prompt,
        'test_command': testCommand,
        'max_retries': maxRetries,
      });
      
      return CodeTask.fromJson(response.data);
    } catch (e) {
      throw _handleError(e);
    }
  }
  
  Future<CodeTask> getTaskStatus(String taskId) async {
    try {
      final response = await _dio.get('/v1/tasks/$taskId');
      return CodeTask.fromJson(response.data);
    } catch (e) {
      throw _handleError(e);
    }
  }
  
  Future<List<CodeTask>> getTaskHistory({
    String? projectId,
    int limit = 20,
  }) async {
    try {
      final response = await _dio.get('/v1/tasks', queryParameters: {
        if (projectId != null) 'project_id': projectId,
        'limit': limit,
      });
      
      return (response.data['tasks'] as List)
          .map((json) => CodeTask.fromJson(json))
          .toList();
    } catch (e) {
      throw _handleError(e);
    }
  }
  
  // ============================================================
  // Real-time Updates via WebSocket
  // ============================================================
  
  Stream<ExecutionLog> subscribeToTaskUpdates(String taskId) {
    final wsUrl = baseUrl.replaceFirst('http', 'ws');
    _wsChannel = WebSocketChannel.connect(
      Uri.parse('$wsUrl/v1/tasks/$taskId/stream'),
    );
    
    return _wsChannel!.stream.map((data) {
      final json = jsonDecode(data);
      return ExecutionLog.fromJson(json);
    });
  }
  
  void unsubscribeFromTaskUpdates() {
    _wsChannel?.sink.close();
    _wsChannel = null;
  }
  
  // ============================================================
  // Project Management
  // ============================================================
  
  Future<Project> createProject({
    required String name,
    required String path,
    required String language,
  }) async {
    try {
      final response = await _dio.post('/v1/projects', data: {
        'name': name,
        'path': path,
        'language': language,
      });
      
      return Project.fromJson(response.data);
    } catch (e) {
      throw _handleError(e);
    }
  }
  
  Future<List<Project>> getProjects() async {
    try {
      final response = await _dio.get('/v1/projects');
      return (response.data['projects'] as List)
          .map((json) => Project.fromJson(json))
          .toList();
    } catch (e) {
      throw _handleError(e);
    }
  }
  
  Future<void> indexProject(String projectId) async {
    try {
      await _dio.post('/v1/projects/$projectId/index');
    } catch (e) {
      throw _handleError(e);
    }
  }
  
  // ============================================================
  // Tool Statistics
  // ============================================================
  
  Future<List<ToolStats>> getToolStats() async {
    try {
      final response = await _dio.get('/v1/stats/tools');
      return (response.data['tools'] as List)
          .map((json) => ToolStats.fromJson(json))
          .toList();
    } catch (e) {
      throw _handleError(e);
    }
  }
  
  // ============================================================
  // Architecture Info
  // ============================================================
  
  Future<List<ArchitectureComponent>> getArchitectureComponents() async {
    try {
      final response = await _dio.get('/v1/architecture/components');
      return (response.data['components'] as List)
          .map((json) => ArchitectureComponent.fromJson(json))
          .toList();
    } catch (e) {
      throw _handleError(e);
    }
  }
  
  // ============================================================
  // Error Handling
  // ============================================================
  
  Exception _handleError(dynamic error) {
    if (error is DioException) {
      switch (error.type) {
        case DioExceptionType.connectionTimeout:
        case DioExceptionType.sendTimeout:
        case DioExceptionType.receiveTimeout:
          return TimeoutException('Request timeout');
        case DioExceptionType.badResponse:
          return Exception(
            error.response?.data['message'] ?? 'Server error',
          );
        case DioExceptionType.connectionError:
          return Exception('Connection error. Check your network.');
        default:
          return Exception('Unknown error occurred');
      }
    }
    return Exception(error.toString());
  }
  
  void dispose() {
    _wsChannel?.sink.close();
    _dio.close();
  }
}

// ============================================================
// Mock Service for Development/Demo
// ============================================================

class MockGoatCodeService {
  final List<CodeTask> _tasks = [];
  final List<Project> _projects = [];
  
  Future<CodeTask> createTask({
    required String projectId,
    required String prompt,
    String testCommand = 'pytest',
    int maxRetries = 5,
  }) async {
    await Future.delayed(const Duration(milliseconds: 500));
    
    final task = CodeTask(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      projectId: projectId,
      prompt: prompt,
      status: TaskStatus.queued,
      createdAt: DateTime.now(),
      metrics: TaskMetrics.initial(),
    );
    
    _tasks.add(task);
    
    // Simulate execution in background
    _simulateExecution(task.id);
    
    return task;
  }
  
  Future<CodeTask> getTaskStatus(String taskId) async {
    await Future.delayed(const Duration(milliseconds: 100));
    
    final task = _tasks.firstWhere(
      (t) => t.id == taskId,
      orElse: () => throw Exception('Task not found'),
    );
    
    return task;
  }
  
  Stream<ExecutionLog> subscribeToTaskUpdates(String taskId) async* {
    final phases = [
      (ExecutionPhase.intentAnalysis, 'Extracting goal and constraints...', 300),
      (ExecutionPhase.projectContext, 'Indexing codebase with semantic embeddings...', 500),
      (ExecutionPhase.fileIndex, 'Indexed 1,247 files in 340ms using AST parsing', 400),
      (ExecutionPhase.riskAnalysis, 'Analyzing security, performance, concurrency concerns...', 600),
      (ExecutionPhase.implementationPlan, 'Generated 5-step execution plan', 300),
      (ExecutionPhase.codeGeneration, 'Generating diff-based patches...', 700),
      (ExecutionPhase.validation, 'Running linter, typecheck, unit tests...', 800),
      (ExecutionPhase.testResults, '✓ 23/23 tests passed', 400),
      (ExecutionPhase.confidence, 'Confidence score: 0.94', 200),
      (ExecutionPhase.complete, 'Task completed. Memory pattern stored.', 300),
    ];
    
    for (final (phase, message, delay) in phases) {
      await Future.delayed(Duration(milliseconds: delay));
      yield ExecutionLog(
        phase: phase,
        message: message,
        timestamp: DateTime.now(),
      );
    }
  }
  
  void _simulateExecution(String taskId) async {
    final taskIndex = _tasks.indexWhere((t) => t.id == taskId);
    if (taskIndex == -1) return;
    
    // Update to running
    await Future.delayed(const Duration(seconds: 1));
    _tasks[taskIndex] = _tasks[taskIndex].copyWith(
      status: TaskStatus.running,
    );
    
    // Simulate execution phases
    await Future.delayed(const Duration(seconds: 5));
    
    // Complete
    _tasks[taskIndex] = _tasks[taskIndex].copyWith(
      status: TaskStatus.success,
      completedAt: DateTime.now(),
      metrics: _tasks[taskIndex].metrics?.copyWith(
        filesIndexed: 1247,
        testsPassed: 23,
        confidence: 0.94,
        iterationCount: 3,
        contextTokens: 45000,
      ),
      code: GeneratedCode(
        filePath: 'auth/oauth.py',
        content: '''
def authenticate_oauth2(code: str, redirect_uri: str) -> AuthToken:
    """
    Implement OAuth2 authentication with PKCE flow.
    
    Args:
        code: Authorization code from OAuth provider
        redirect_uri: Redirect URI used in authorization request
    
    Returns:
        AuthToken with access and refresh tokens
    
    Raises:
        AuthenticationError: If authentication fails
    """
    if not code or not redirect_uri:
        raise ValueError("Code and redirect_uri required")
    
    # Exchange code for tokens
    token_response = exchange_authorization_code(
        code=code,
        redirect_uri=redirect_uri,
        code_verifier=get_code_verifier()
    )
    
    # Validate tokens
    validate_token_response(token_response)
    
    # Store tokens securely
    return store_tokens_securely(token_response)
''',
        language: 'python',
        validation: ValidationReport(
          securityReviewPassed: true,
          lintClean: true,
          typecheckClean: true,
          edgeCasesConsidered: [
            'Invalid authorization code',
            'Expired code verifier',
            'Network timeout',
            'Token validation failure',
          ],
        ),
      ),
    );
  }
  
  Future<List<Project>> getProjects() async {
    await Future.delayed(const Duration(milliseconds: 300));
    
    if (_projects.isEmpty) {
      _projects.addAll([
        Project(
          id: '1',
          name: 'E-Commerce Platform',
          path: '/projects/ecommerce',
          language: 'Python',
          createdAt: DateTime.now().subtract(const Duration(days: 30)),
          lastIndexed: DateTime.now().subtract(const Duration(hours: 2)),
          filesCount: 1247,
        ),
        Project(
          id: '2',
          name: 'Mobile App Backend',
          path: '/projects/mobile-api',
          language: 'TypeScript',
          createdAt: DateTime.now().subtract(const Duration(days: 15)),
          lastIndexed: DateTime.now().subtract(const Duration(hours: 5)),
          filesCount: 563,
        ),
      ]);
    }
    
    return _projects;
  }
  
  Future<List<ToolStats>> getToolStats() async {
    await Future.delayed(const Duration(milliseconds: 200));
    
    return [
      ToolStats(name: 'read_file', calls: 1247, avgTime: '12ms', successRate: 99),
      ToolStats(name: 'write_file', calls: 89, avgTime: '34ms', successRate: 98),
      ToolStats(name: 'list_directory', calls: 234, avgTime: '8ms', successRate: 100),
      ToolStats(name: 'search_project', calls: 456, avgTime: '67ms', successRate: 97),
      ToolStats(name: 'run_tests', calls: 34, avgTime: '1.2s', successRate: 94),
      ToolStats(name: 'run_linter', calls: 28, avgTime: '340ms', successRate: 96),
      ToolStats(name: 'run_typecheck', calls: 23, avgTime: '890ms', successRate: 95),
      ToolStats(name: 'git_diff', calls: 91, avgTime: '45ms', successRate: 99),
    ];
  }
  
  Future<List<ArchitectureComponent>> getArchitectureComponents() async {
    await Future.delayed(const Duration(milliseconds: 200));
    
    return [
      ArchitectureComponent(
        name: 'File Indexing Engine',
        description: 'AST-based semantic indexing with vector embeddings',
        tech: 'tree-sitter + FAISS',
        status: 'active',
        iconName: 'file-search',
      ),
      ArchitectureComponent(
        name: 'Context Injection',
        description: 'Automatic relevance-based context retrieval',
        tech: 'semantic search + reranking',
        status: 'active',
        iconName: 'layers',
      ),
      ArchitectureComponent(
        name: 'Test→Fix→Retry Loop',
        description: 'Iterative compilation with error recovery',
        tech: 'pytest + retry strategy',
        status: 'active',
        iconName: 'refresh-cw',
      ),
      ArchitectureComponent(
        name: 'Diff-Based Patching',
        description: 'AST-aware minimal diffs, not full rewrites',
        tech: 'unidiff + AST parser',
        status: 'active',
        iconName: 'git-branch',
      ),
      ArchitectureComponent(
        name: 'Token Budget Manager',
        description: 'Dynamic context window optimization',
        tech: 'tiktoken + sliding window',
        status: 'active',
        iconName: 'bar-chart-3',
      ),
      ArchitectureComponent(
        name: 'Memory Patterns',
        description: 'Resolution pattern storage and retrieval',
        tech: 'vector DB + LRU cache',
        status: 'active',
        iconName: 'database',
      ),
    ];
  }
}
