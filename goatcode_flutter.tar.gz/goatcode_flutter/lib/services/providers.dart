import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/models.dart';
import '../services/api_service.dart';

// ============================================================
// Service Providers
// ============================================================

final apiServiceProvider = Provider<MockGoatCodeService>((ref) {
  // In production, replace with real GoatCodeApiService
  return MockGoatCodeService();
});

// ============================================================
// Project Providers
// ============================================================

final projectsProvider = FutureProvider<List<Project>>((ref) async {
  final api = ref.watch(apiServiceProvider);
  return await api.getProjects();
});

final selectedProjectProvider = StateProvider<Project?>((ref) => null);

// ============================================================
// Task Providers
// ============================================================

class TaskNotifier extends StateNotifier<AsyncValue<CodeTask?>> {
  final MockGoatCodeService _api;
  
  TaskNotifier(this._api) : super(const AsyncValue.data(null));
  
  Future<void> createTask({
    required String projectId,
    required String prompt,
  }) async {
    state = const AsyncValue.loading();
    
    try {
      final task = await _api.createTask(
        projectId: projectId,
        prompt: prompt,
      );
      state = AsyncValue.data(task);
      
      // Start polling for updates
      _pollTaskStatus(task.id);
    } catch (error, stack) {
      state = AsyncValue.error(error, stack);
    }
  }
  
  Future<void> _pollTaskStatus(String taskId) async {
    while (true) {
      await Future.delayed(const Duration(seconds: 1));
      
      try {
        final task = await _api.getTaskStatus(taskId);
        state = AsyncValue.data(task);
        
        if (task.status == TaskStatus.success ||
            task.status == TaskStatus.failed ||
            task.status == TaskStatus.error) {
          break;
        }
      } catch (error, stack) {
        state = AsyncValue.error(error, stack);
        break;
      }
    }
  }
  
  void clearTask() {
    state = const AsyncValue.data(null);
  }
}

final currentTaskProvider =
    StateNotifierProvider<TaskNotifier, AsyncValue<CodeTask?>>(
  (ref) => TaskNotifier(ref.watch(apiServiceProvider)),
);

// ============================================================
// Execution Log Stream Provider
// ============================================================

final executionLogsProvider =
    StreamProvider.family<List<ExecutionLog>, String>((ref, taskId) {
  final api = ref.watch(apiServiceProvider);
  
  final logs = <ExecutionLog>[];
  
  return api.subscribeToTaskUpdates(taskId).map((log) {
    logs.add(log);
    return List.from(logs);
  });
});

// ============================================================
// Statistics Providers
// ============================================================

final toolStatsProvider = FutureProvider<List<ToolStats>>((ref) async {
  final api = ref.watch(apiServiceProvider);
  return await api.getToolStats();
});

final architectureComponentsProvider =
    FutureProvider<List<ArchitectureComponent>>((ref) async {
  final api = ref.watch(apiServiceProvider);
  return await api.getArchitectureComponents();
});

// ============================================================
// Metrics Provider
// ============================================================

final metricsProvider = Provider<TaskMetrics>((ref) {
  final taskAsync = ref.watch(currentTaskProvider);
  
  return taskAsync.when(
    data: (task) => task?.metrics ?? TaskMetrics.initial(),
    loading: () => TaskMetrics.initial(),
    error: (_, __) => TaskMetrics.initial(),
  );
});
