import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../models/models.dart';
import '../services/providers.dart';
import '../widgets/metric_card.dart';
import '../widgets/execution_log_widget.dart';

class AgentControlScreen extends ConsumerStatefulWidget {
  const AgentControlScreen({super.key});

  @override
  ConsumerState<AgentControlScreen> createState() => _AgentControlScreenState();
}

class _AgentControlScreenState extends ConsumerState<AgentControlScreen> {
  final _promptController = TextEditingController();
  
  @override
  void initState() {
    super.initState();
    _promptController.text = '''Implement OAuth2 authentication flow with JWT tokens. Requirements:
- Secure token storage
- Refresh token rotation
- Rate limiting
- PKCE flow for SPAs''';
  }

  @override
  void dispose() {
    _promptController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final projectsAsync = ref.watch(projectsProvider);
    final selectedProject = ref.watch(selectedProjectProvider);
    final taskAsync = ref.watch(currentTaskProvider);
    final metrics = ref.watch(metricsProvider);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Project Selection
          projectsAsync.when(
            data: (projects) => _buildProjectSelector(projects, selectedProject),
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (error, stack) => Text('Error: $error'),
          ),
          
          const SizedBox(height: 24),
          
          // Main Content Grid
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Left Column: Task Input
              Expanded(
                flex: 1,
                child: _buildTaskInputCard(taskAsync),
              ),
              
              const SizedBox(width: 24),
              
              // Right Column: Live Metrics
              Expanded(
                flex: 1,
                child: _buildMetricsCard(metrics),
              ),
            ],
          ),
          
          const SizedBox(height: 24),
          
          // Execution Logs
          _buildExecutionLogsCard(taskAsync),
        ],
      ),
    );
  }

  Widget _buildProjectSelector(List<Project> projects, Project? selected) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF000000).withOpacity(0.4),
        border: Border.all(
          color: const Color(0xFF00d4ff).withOpacity(0.2),
        ),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          const Icon(
            LucideIcons.folder,
            color: Color(0xFF00d4ff),
            size: 20,
          ),
          const SizedBox(width: 12),
          const Text(
            'Project:',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.5,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: DropdownButton<Project>(
              value: selected ?? (projects.isNotEmpty ? projects.first : null),
              isExpanded: true,
              underline: const SizedBox(),
              dropdownColor: const Color(0xFF1a1a2e),
              style: const TextStyle(
                color: Color(0xFF00d4ff),
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
              items: projects.map((project) {
                return DropdownMenuItem(
                  value: project,
                  child: Text(project.name),
                );
              }).toList(),
              onChanged: (project) {
                ref.read(selectedProjectProvider.notifier).state = project;
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTaskInputCard(AsyncValue<CodeTask?> taskAsync) {
    final isRunning = taskAsync.when(
      data: (task) => task?.status == TaskStatus.running,
      loading: () => false,
      error: (_, __) => false,
    );

    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: const Color(0xFF000000).withOpacity(0.4),
        border: Border.all(
          color: const Color(0xFF00ff9d).withOpacity(0.2),
        ),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(
                LucideIcons.fileCode,
                color: Color(0xFF00ff9d),
                size: 24,
              ),
              const SizedBox(width: 12),
              const Text(
                'Task Definition',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: Color(0xFF00ff9d),
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          
          // Prompt Input
          TextField(
            controller: _promptController,
            maxLines: 10,
            style: const TextStyle(
              fontSize: 14,
              height: 1.5,
            ),
            decoration: const InputDecoration(
              hintText: 'Describe your coding task...',
              hintStyle: TextStyle(color: Color(0xFF666666)),
            ),
          ),
          
          const SizedBox(height: 20),
          
          // Execute Button
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: isRunning ? null : _executeTask,
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                backgroundColor: isRunning
                    ? const Color(0xFF666666)
                    : const Color(0xFF00ff9d),
                disabledBackgroundColor: const Color(0xFF666666).withOpacity(0.3),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    isRunning ? LucideIcons.refreshCw : LucideIcons.play,
                    size: 20,
                  ),
                  const SizedBox(width: 12),
                  Text(
                    isRunning ? 'EXECUTING...' : 'EXECUTE AGENT',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1.5,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMetricsCard(TaskMetrics metrics) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: const Color(0xFF000000).withOpacity(0.4),
        border: Border.all(
          color: const Color(0xFF00d4ff).withOpacity(0.2),
        ),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(
                LucideIcons.barChart3,
                color: Color(0xFF00d4ff),
                size: 24,
              ),
              const SizedBox(width: 12),
              const Text(
                'Live Metrics',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: Color(0xFF00d4ff),
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          
          MetricCard(
            label: 'Context Tokens',
            value: '${metrics.contextTokens.toStringAsFixed(0)} / ${metrics.maxTokens}',
            percentage: (metrics.contextTokens / metrics.maxTokens) * 100,
            color: const Color(0xFF00ff9d),
          ),
          const SizedBox(height: 12),
          
          MetricCard(
            label: 'Files Indexed',
            value: metrics.filesIndexed.toString(),
            color: const Color(0xFF00d4ff),
          ),
          const SizedBox(height: 12),
          
          MetricCard(
            label: 'Tests Passed',
            value: '${metrics.testsPassed} / ${metrics.testsPassed + metrics.testsFailed}',
            color: const Color(0xFF00ff9d),
          ),
          const SizedBox(height: 12),
          
          MetricCard(
            label: 'Iterations',
            value: metrics.iterationCount.toString(),
            color: const Color(0xFFff6b6b),
          ),
          const SizedBox(height: 12),
          
          MetricCard(
            label: 'Confidence Score',
            value: metrics.confidence.toStringAsFixed(2),
            percentage: metrics.confidence * 100,
            color: const Color(0xFFffd93d),
          ),
        ],
      ),
    );
  }

  Widget _buildExecutionLogsCard(AsyncValue<CodeTask?> taskAsync) {
    return Container(
      constraints: const BoxConstraints(
        minHeight: 400,
        maxHeight: 600,
      ),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: const Color(0xFF000000).withOpacity(0.6),
        border: Border.all(
          color: const Color(0xFF00ff9d).withOpacity(0.2),
        ),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(
                LucideIcons.terminal,
                color: Color(0xFF00ff9d),
                size: 24,
              ),
              const SizedBox(width: 12),
              const Text(
                'Execution Log',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: Color(0xFF00ff9d),
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          
          Expanded(
            child: taskAsync.when(
              data: (task) {
                if (task == null) {
                  return const Center(
                    child: Text(
                      'Awaiting task execution...',
                      style: TextStyle(
                        color: Color(0xFF666666),
                        fontSize: 14,
                      ),
                    ),
                  );
                }
                
                // Watch execution logs stream
                final logsAsync = ref.watch(executionLogsProvider(task.id));
                
                return logsAsync.when(
                  data: (logs) => ExecutionLogWidget(logs: logs),
                  loading: () => const Center(
                    child: CircularProgressIndicator(
                      color: Color(0xFF00ff9d),
                    ),
                  ),
                  error: (error, stack) => Center(
                    child: Text('Error: $error'),
                  ),
                );
              },
              loading: () => const Center(
                child: CircularProgressIndicator(
                  color: Color(0xFF00ff9d),
                ),
              ),
              error: (error, stack) => Center(
                child: Text('Error: $error'),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _executeTask() {
    final selectedProject = ref.read(selectedProjectProvider);
    
    if (selectedProject == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a project')),
      );
      return;
    }
    
    if (_promptController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a task description')),
      );
      return;
    }
    
    ref.read(currentTaskProvider.notifier).createTask(
      projectId: selectedProject.id,
      prompt: _promptController.text,
    );
  }
}
