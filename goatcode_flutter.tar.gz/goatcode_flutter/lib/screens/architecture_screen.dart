import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../models/models.dart';
import '../services/providers.dart';

class ArchitectureScreen extends ConsumerWidget {
  const ArchitectureScreen({super.key});

  IconData _getIconForName(String iconName) {
    final iconMap = {
      'file-search': LucideIcons.fileSearch,
      'layers': LucideIcons.layers,
      'refresh-cw': LucideIcons.refreshCw,
      'git-branch': LucideIcons.gitBranch,
      'bar-chart-3': LucideIcons.barChart3,
      'database': LucideIcons.database,
    };
    return iconMap[iconName] ?? LucideIcons.box;
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final componentsAsync = ref.watch(architectureComponentsProvider);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          const Text(
            'The 80% — Real Architecture',
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.w700,
              color: Color(0xFF00ff9d),
              letterSpacing: 0.5,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Prompts are 20%. These components are the 80% that actually beat other agents.',
            style: TextStyle(
              fontSize: 16,
              color: Color(0xFF888888),
              height: 1.6,
            ),
          ),
          const SizedBox(height: 32),
          
          // Components Grid
          componentsAsync.when(
            data: (components) => _buildComponentsGrid(components),
            loading: () => const Center(
              child: CircularProgressIndicator(color: Color(0xFF00ff9d)),
            ),
            error: (error, stack) => Center(
              child: Text('Error: $error'),
            ),
          ),
          
          const SizedBox(height: 48),
          
          // Pipeline Diagram
          _buildPipelineDiagram(),
        ],
      ),
    );
  }

  Widget _buildComponentsGrid(List<ArchitectureComponent> components) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 20,
        mainAxisSpacing: 20,
        childAspectRatio: 1.5,
      ),
      itemCount: components.length,
      itemBuilder: (context, index) {
        return _buildComponentCard(components[index]);
      },
    );
  }

  Widget _buildComponentCard(ArchitectureComponent component) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: const Color(0xFF000000).withOpacity(0.4),
        border: Border.all(
          color: const Color(0xFF00ff9d).withOpacity(0.2),
        ),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFF00ff9d).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(
                  _getIconForName(component.iconName),
                  color: const Color(0xFF00ff9d),
                  size: 28,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0xFF00d4ff).withOpacity(0.1),
                  border: Border.all(
                    color: const Color(0xFF00d4ff).withOpacity(0.3),
                  ),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(
                  component.status.toUpperCase(),
                  style: const TextStyle(
                    fontSize: 10,
                    color: Color(0xFF00d4ff),
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Text(
            component.name,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: Color(0xFFe0e0e0),
            ),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: Text(
              component.description,
              style: TextStyle(
                fontSize: 13,
                color: const Color(0xFFaaaaaa),
                height: 1.5,
              ),
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: const Color(0xFF000000).withOpacity(0.3),
              borderRadius: BorderRadius.circular(6),
            ),
            child: Row(
              children: [
                const Icon(
                  LucideIcons.code2,
                  color: Color(0xFF00ff9d),
                  size: 16,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    component.tech,
                    style: const TextStyle(
                      fontSize: 12,
                      color: Color(0xFF00ff9d),
                      fontWeight: FontWeight.w600,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPipelineDiagram() {
    final steps = [
      'Intent Analysis',
      'Context Injection',
      'Plan Generation',
      'Code Generation',
      'Test Execution',
      'Validation',
      'Memory Storage',
    ];

    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: const Color(0xFF000000).withOpacity(0.4),
        border: Border.all(
          color: const Color(0xFF00d4ff).withOpacity(0.2),
        ),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Execution Pipeline',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w700,
              color: Color(0xFF00d4ff),
              letterSpacing: 0.5,
            ),
          ),
          const SizedBox(height: 24),
          Wrap(
            spacing: 16,
            runSpacing: 16,
            children: steps.asMap().entries.map((entry) {
              final index = entry.key;
              final step = entry.value;
              
              return Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 12,
                    ),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          const Color(0xFF00ff9d).withOpacity(0.1),
                          const Color(0xFF00d4ff).withOpacity(0.1),
                        ],
                      ),
                      border: Border.all(
                        color: const Color(0xFF00ff9d).withOpacity(0.3),
                      ),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      step,
                      style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: Color(0xFFe0e0e0),
                      ),
                    ),
                  ),
                  if (index < steps.length - 1) ...[
                    const SizedBox(width: 8),
                    Icon(
                      LucideIcons.arrowRight,
                      color: const Color(0xFF00ff9d).withOpacity(0.5),
                      size: 20,
                    ),
                  ],
                ],
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}
