import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../services/providers.dart';
import 'agent_control_screen.dart';
import 'architecture_screen.dart';
import 'tools_stats_screen.dart';
import 'metrics_screen.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _tabController.addListener(() {
      setState(() {
        _currentIndex = _tabController.index;
      });
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final taskAsync = ref.watch(currentTaskProvider);
    final taskStatus = taskAsync.when(
      data: (task) => task?.status ?? TaskStatus.idle,
      loading: () => TaskStatus.idle,
      error: (_, __) => TaskStatus.idle,
    );

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFF0a0a0a),
              Color(0xFF1a1a2e),
              Color(0xFF16213e),
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Header
              _buildHeader(taskStatus),
              
              // Tab Bar
              _buildTabBar(),
              
              // Content
              Expanded(
                child: TabBarView(
                  controller: _tabController,
                  children: const [
                    AgentControlScreen(),
                    ArchitectureScreen(),
                    ToolsStatsScreen(),
                    MetricsScreen(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(TaskStatus status) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: const Color(0xFF0a0a0a).withOpacity(0.8),
        border: Border(
          bottom: BorderSide(
            color: const Color(0xFF00ff9d).withOpacity(0.2),
          ),
        ),
      ),
      child: Row(
        children: [
          // Logo and Title
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: const Color(0xFF00ff9d).withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF00ff9d).withOpacity(0.3),
                  blurRadius: 12,
                ),
              ],
            ),
            child: const Icon(
              LucideIcons.cpu,
              color: Color(0xFF00ff9d),
              size: 32,
            ),
          ),
          const SizedBox(width: 16),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ShaderMask(
                shaderCallback: (bounds) => const LinearGradient(
                  colors: [Color(0xFF00ff9d), Color(0xFF00d4ff)],
                ).createShader(bounds),
                child: const Text(
                  'GOATCODE',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.2,
                    color: Colors.white,
                  ),
                ),
              ),
              Text(
                'DETERMINISTIC AGENT ARCHITECTURE',
                style: TextStyle(
                  fontSize: 10,
                  color: const Color(0xFF00ff9d).withOpacity(0.8),
                  letterSpacing: 2,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          const Spacer(),
          
          // Status Badge
          _buildStatusBadge(status),
        ],
      ),
    );
  }

  Widget _buildStatusBadge(TaskStatus status) {
    Color color;
    IconData icon;
    String text;

    switch (status) {
      case TaskStatus.running:
        color = const Color(0xFF00ff9d);
        icon = LucideIcons.zap;
        text = 'RUNNING';
        break;
      case TaskStatus.success:
        color = const Color(0xFF00d4ff);
        icon = LucideIcons.checkCircle;
        text = 'SUCCESS';
        break;
      case TaskStatus.failed:
      case TaskStatus.error:
        color = const Color(0xFFff6b6b);
        icon = LucideIcons.alertCircle;
        text = 'ERROR';
        break;
      default:
        color = const Color(0xFF666666);
        icon = LucideIcons.terminal;
        text = 'IDLE';
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        border: Border.all(color: color.withOpacity(0.3)),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 16),
          const SizedBox(width: 8),
          Text(
            text,
            style: TextStyle(
              color: color,
              fontSize: 12,
              fontWeight: FontWeight.w700,
              letterSpacing: 1.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabBar() {
    final tabs = [
      (LucideIcons.terminal, 'Agent Control'),
      (LucideIcons.layout, 'Architecture'),
      (LucideIcons.code2, 'Tool Stats'),
      (LucideIcons.barChart3, 'Metrics'),
    ];

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
      decoration: BoxDecoration(
        color: const Color(0xFF000000).withOpacity(0.3),
        border: Border(
          bottom: BorderSide(
            color: Colors.white.withOpacity(0.05),
          ),
        ),
      ),
      child: Row(
        children: tabs.asMap().entries.map((entry) {
          final index = entry.key;
          final (icon, label) = entry.value;
          final isSelected = _currentIndex == index;

          return Expanded(
            child: GestureDetector(
              onTap: () => _tabController.animateTo(index),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 12),
                margin: const EdgeInsets.symmetric(horizontal: 4),
                decoration: BoxDecoration(
                  gradient: isSelected
                      ? LinearGradient(
                          colors: [
                            const Color(0xFF00ff9d).withOpacity(0.15),
                            const Color(0xFF00d4ff).withOpacity(0.15),
                          ],
                        )
                      : null,
                  border: isSelected
                      ? Border.all(
                          color: const Color(0xFF00ff9d).withOpacity(0.3),
                        )
                      : Border.all(color: Colors.transparent),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      icon,
                      size: 18,
                      color: isSelected
                          ? const Color(0xFF00ff9d)
                          : const Color(0xFF888888),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      label,
                      style: TextStyle(
                        color: isSelected
                            ? const Color(0xFF00ff9d)
                            : const Color(0xFF888888),
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}
