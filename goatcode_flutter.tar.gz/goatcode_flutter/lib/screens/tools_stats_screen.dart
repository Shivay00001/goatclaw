import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/models.dart';
import '../services/providers.dart';

class ToolsStatsScreen extends ConsumerWidget {
  const ToolsStatsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final toolStatsAsync = ref.watch(toolStatsProvider);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Tool Orchestration Stats',
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.w700,
              color: Color(0xFF00ff9d),
              letterSpacing: 0.5,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Real-time performance metrics for deterministic tool execution',
            style: TextStyle(
              fontSize: 16,
              color: Color(0xFF888888),
            ),
          ),
          const SizedBox(height: 32),
          
          toolStatsAsync.when(
            data: (stats) => _buildStatsTable(stats),
            loading: () => const Center(
              child: CircularProgressIndicator(color: Color(0xFF00ff9d)),
            ),
            error: (error, stack) => Center(
              child: Text('Error: $error'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatsTable(List<ToolStats> stats) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF000000).withOpacity(0.4),
        border: Border.all(
          color: const Color(0xFF00ff9d).withOpacity(0.2),
        ),
        borderRadius: BorderRadius.circular(12),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Table(
          columnWidths: const {
            0: FlexColumnWidth(2),
            1: FlexColumnWidth(1),
            2: FlexColumnWidth(1),
            3: FlexColumnWidth(1),
          },
          children: [
            // Header
            TableRow(
              decoration: BoxDecoration(
                color: const Color(0xFF00ff9d).withOpacity(0.1),
                border: Border(
                  bottom: BorderSide(
                    color: const Color(0xFF00ff9d).withOpacity(0.3),
                  ),
                ),
              ),
              children: [
                _buildHeaderCell('TOOL NAME'),
                _buildHeaderCell('CALLS'),
                _buildHeaderCell('AVG TIME'),
                _buildHeaderCell('SUCCESS'),
              ],
            ),
            
            // Data Rows
            ...stats.map((stat) => _buildDataRow(stat)),
          ],
        ),
      ),
    );
  }

  Widget _buildHeaderCell(String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
      child: Text(
        text,
        style: const TextStyle(
          color: Color(0xFF00ff9d),
          fontSize: 12,
          fontWeight: FontWeight.w700,
          letterSpacing: 1,
        ),
      ),
    );
  }

  TableRow _buildDataRow(ToolStats stat) {
    return TableRow(
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: Colors.white.withOpacity(0.05),
          ),
        ),
      ),
      children: [
        _buildDataCell(
          stat.name,
          const TextStyle(
            fontSize: 14,
            color: Color(0xFFe0e0e0),
          ),
        ),
        _buildDataCell(
          stat.calls.toString(),
          const TextStyle(
            fontSize: 15,
            color: Color(0xFF00d4ff),
            fontWeight: FontWeight.w600,
          ),
        ),
        _buildDataCell(
          stat.avgTime,
          const TextStyle(
            fontSize: 13,
            color: Color(0xFFaaaaaa),
          ),
        ),
        _buildDataCell(
          '${stat.successRate}%',
          TextStyle(
            fontSize: 13,
            color: stat.successRate >= 95
                ? const Color(0xFF00ff9d)
                : stat.successRate >= 90
                    ? const Color(0xFFffd93d)
                    : const Color(0xFFff6b6b),
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }

  Widget _buildDataCell(String text, TextStyle style) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
      child: Text(text, style: style),
    );
  }
}
