import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';

class MetricsScreen extends ConsumerWidget {
  const MetricsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Performance Metrics',
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.w700,
              color: Color(0xFF00ff9d),
              letterSpacing: 0.5,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Token optimization, context management, and execution efficiency',
            style: TextStyle(
              fontSize: 16,
              color: Color(0xFF888888),
            ),
          ),
          const SizedBox(height: 32),
          
          GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 2,
            crossAxisSpacing: 20,
            mainAxisSpacing: 20,
            childAspectRatio: 1.8,
            children: [
              _buildLargeMetricCard(
                title: 'Context Efficiency',
                value: '87.3%',
                subtitle: 'Optimal token utilization',
                color: const Color(0xFF00ff9d),
                icon: LucideIcons.database,
              ),
              _buildLargeMetricCard(
                title: 'Success Rate',
                value: '94.7%',
                subtitle: 'First-attempt correctness',
                color: const Color(0xFF00d4ff),
                icon: LucideIcons.checkCircle,
              ),
              _buildLargeMetricCard(
                title: 'Avg Response Time',
                value: '2.3s',
                subtitle: 'End-to-end latency',
                color: const Color(0xFFffd93d),
                icon: LucideIcons.zap,
              ),
              _buildLargeMetricCard(
                title: 'Security Score',
                value: '100%',
                subtitle: 'Zero vulnerabilities detected',
                color: const Color(0xFF00ff9d),
                icon: LucideIcons.shield,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildLargeMetricCard({
    required String title,
    required String value,
    required String subtitle,
    required Color color,
    required IconData icon,
  }) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: const Color(0xFF000000).withOpacity(0.4),
        border: Border.all(
          color: color.withOpacity(0.3),
        ),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 13,
                      color: Color(0xFF888888),
                      letterSpacing: 0.5,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    value,
                    style: TextStyle(
                      fontSize: 36,
                      fontWeight: FontWeight.w800,
                      color: color,
                      height: 1,
                    ),
                  ),
                ],
              ),
              Icon(
                icon,
                size: 40,
                color: color.withOpacity(0.3),
              ),
            ],
          ),
          const Spacer(),
          Text(
            subtitle,
            style: const TextStyle(
              fontSize: 13,
              color: Color(0xFFaaaaaa),
            ),
          ),
        ],
      ),
    );
  }
}
