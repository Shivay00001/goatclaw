import 'package:json_annotation/json_annotation.dart';

part 'models.g.dart';

// ============================================================
// Task Models
// ============================================================

enum TaskStatus {
  idle,
  queued,
  running,
  success,
  failed,
  error
}

enum ExecutionPhase {
  intentAnalysis,
  projectContext,
  fileIndex,
  riskAnalysis,
  implementationPlan,
  codeGeneration,
  validation,
  testResults,
  confidence,
  complete
}

@JsonSerializable()
class CodeTask {
  final String id;
  final String projectId;
  final String prompt;
  final TaskStatus status;
  final DateTime createdAt;
  final DateTime? completedAt;
  final List<ExecutionLog> logs;
  final TaskMetrics? metrics;
  final GeneratedCode? code;
  
  CodeTask({
    required this.id,
    required this.projectId,
    required this.prompt,
    required this.status,
    required this.createdAt,
    this.completedAt,
    this.logs = const [],
    this.metrics,
    this.code,
  });
  
  factory CodeTask.fromJson(Map<String, dynamic> json) => _$CodeTaskFromJson(json);
  Map<String, dynamic> toJson() => _$CodeTaskToJson(this);
  
  CodeTask copyWith({
    String? id,
    String? projectId,
    String? prompt,
    TaskStatus? status,
    DateTime? createdAt,
    DateTime? completedAt,
    List<ExecutionLog>? logs,
    TaskMetrics? metrics,
    GeneratedCode? code,
  }) {
    return CodeTask(
      id: id ?? this.id,
      projectId: projectId ?? this.projectId,
      prompt: prompt ?? this.prompt,
      status: status ?? this.status,
      createdAt: createdAt ?? this.createdAt,
      completedAt: completedAt ?? this.completedAt,
      logs: logs ?? this.logs,
      metrics: metrics ?? this.metrics,
      code: code ?? this.code,
    );
  }
}

@JsonSerializable()
class ExecutionLog {
  final ExecutionPhase phase;
  final String message;
  final DateTime timestamp;
  final Map<String, dynamic>? metadata;
  
  ExecutionLog({
    required this.phase,
    required this.message,
    required this.timestamp,
    this.metadata,
  });
  
  factory ExecutionLog.fromJson(Map<String, dynamic> json) => _$ExecutionLogFromJson(json);
  Map<String, dynamic> toJson() => _$ExecutionLogToJson(this);
}

@JsonSerializable()
class TaskMetrics {
  final int contextTokens;
  final int maxTokens;
  final int filesIndexed;
  final int testsPassed;
  final int testsFailed;
  final int iterationCount;
  final double confidence;
  final Duration? executionTime;
  
  TaskMetrics({
    required this.contextTokens,
    required this.maxTokens,
    required this.filesIndexed,
    required this.testsPassed,
    required this.testsFailed,
    required this.iterationCount,
    required this.confidence,
    this.executionTime,
  });
  
  factory TaskMetrics.fromJson(Map<String, dynamic> json) => _$TaskMetricsFromJson(json);
  Map<String, dynamic> toJson() => _$TaskMetricsToJson(this);
  
  factory TaskMetrics.initial() {
    return TaskMetrics(
      contextTokens: 0,
      maxTokens: 190000,
      filesIndexed: 0,
      testsPassed: 0,
      testsFailed: 0,
      iterationCount: 0,
      confidence: 0.0,
    );
  }
  
  TaskMetrics copyWith({
    int? contextTokens,
    int? maxTokens,
    int? filesIndexed,
    int? testsPassed,
    int? testsFailed,
    int? iterationCount,
    double? confidence,
    Duration? executionTime,
  }) {
    return TaskMetrics(
      contextTokens: contextTokens ?? this.contextTokens,
      maxTokens: maxTokens ?? this.maxTokens,
      filesIndexed: filesIndexed ?? this.filesIndexed,
      testsPassed: testsPassed ?? this.testsPassed,
      testsFailed: testsFailed ?? this.testsFailed,
      iterationCount: iterationCount ?? this.iterationCount,
      confidence: confidence ?? this.confidence,
      executionTime: executionTime ?? this.executionTime,
    );
  }
}

@JsonSerializable()
class GeneratedCode {
  final String filePath;
  final String content;
  final String language;
  final String? diff;
  final ValidationReport? validation;
  
  GeneratedCode({
    required this.filePath,
    required this.content,
    required this.language,
    this.diff,
    this.validation,
  });
  
  factory GeneratedCode.fromJson(Map<String, dynamic> json) => _$GeneratedCodeFromJson(json);
  Map<String, dynamic> toJson() => _$GeneratedCodeToJson(this);
}

@JsonSerializable()
class ValidationReport {
  final bool securityReviewPassed;
  final bool lintClean;
  final bool typecheckClean;
  final List<String> edgeCasesConsidered;
  final List<String> warnings;
  
  ValidationReport({
    required this.securityReviewPassed,
    required this.lintClean,
    required this.typecheckClean,
    required this.edgeCasesConsidered,
    this.warnings = const [],
  });
  
  factory ValidationReport.fromJson(Map<String, dynamic> json) => _$ValidationReportFromJson(json);
  Map<String, dynamic> toJson() => _$ValidationReportToJson(this);
}

// ============================================================
// Architecture Components
// ============================================================

@JsonSerializable()
class ArchitectureComponent {
  final String name;
  final String description;
  final String tech;
  final String status;
  final String iconName;
  
  ArchitectureComponent({
    required this.name,
    required this.description,
    required this.tech,
    required this.status,
    required this.iconName,
  });
  
  factory ArchitectureComponent.fromJson(Map<String, dynamic> json) => 
      _$ArchitectureComponentFromJson(json);
  Map<String, dynamic> toJson() => _$ArchitectureComponentToJson(this);
}

// ============================================================
// Tool Statistics
// ============================================================

@JsonSerializable()
class ToolStats {
  final String name;
  final int calls;
  final String avgTime;
  final int successRate;
  
  ToolStats({
    required this.name,
    required this.calls,
    required this.avgTime,
    required this.successRate,
  });
  
  factory ToolStats.fromJson(Map<String, dynamic> json) => _$ToolStatsFromJson(json);
  Map<String, dynamic> toJson() => _$ToolStatsToJson(this);
}

// ============================================================
// Project Model
// ============================================================

@JsonSerializable()
class Project {
  final String id;
  final String name;
  final String path;
  final String language;
  final DateTime createdAt;
  final DateTime lastIndexed;
  final int filesCount;
  
  Project({
    required this.id,
    required this.name,
    required this.path,
    required this.language,
    required this.createdAt,
    required this.lastIndexed,
    required this.filesCount,
  });
  
  factory Project.fromJson(Map<String, dynamic> json) => _$ProjectFromJson(json);
  Map<String, dynamic> toJson() => _$ProjectToJson(this);
}
