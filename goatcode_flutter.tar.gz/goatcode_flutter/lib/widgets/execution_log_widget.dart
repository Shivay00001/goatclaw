import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/models.dart';

class ExecutionLogWidget extends StatefulWidget {
  final List<ExecutionLog> logs;

  const ExecutionLogWidget({
    super.key,
    required this.logs,
  });

  @override
  State<ExecutionLogWidget> createState() => _ExecutionLogWidgetState();
}

class _ExecutionLogWidgetState extends State<ExecutionLogWidget> {
  final ScrollController _scrollController = ScrollController();

  @override
  void didUpdateWidget(ExecutionLogWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    
    // Auto-scroll to bottom when new logs arrive
    if (widget.logs.length > oldWidget.logs.length) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_scrollController.hasClients) {
          _scrollController.animateTo(
            _scrollController.position.maxScrollExtent,
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeOut,
          );
        }
      });
    }
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.logs.isEmpty) {
      return const Center(
        child: Text(
          'No logs yet...',
          style: TextStyle(
            color: Color(0xFF666666),
            fontSize: 14,
          ),
        ),
      );
    }

    return ListView.builder(
      controller: _scrollController,
      itemCount: widget.logs.length,
      itemBuilder: (context, index) {
        return _buildLogEntry(widget.logs[index]);
      },
    );
  }

  Widget _buildLogEntry(ExecutionLog log) {
    final timeFormat = DateFormat('HH:mm:ss');
    
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: Colors.white.withOpacity(0.05),
          ),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Phase Badge
          Container(
            constraints: const BoxConstraints(minWidth: 180),
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: _getPhaseColor(log.phase).withOpacity(0.1),
              border: Border.all(
                color: _getPhaseColor(log.phase).withOpacity(0.3),
              ),
              borderRadius: BorderRadius.circular(4),
            ),
            child: Text(
              _getPhaseLabel(log.phase),
              style: TextStyle(
                fontSize: 11,
                color: _getPhaseColor(log.phase),
                fontWeight: FontWeight.w600,
                letterSpacing: 0.5,
              ),
            ),
          ),
          
          const SizedBox(width: 16),
          
          // Message
          Expanded(
            child: Text(
              log.message,
              style: const TextStyle(
                fontSize: 13,
                color: Color(0xFFe0e0e0),
                height: 1.5,
              ),
            ),
          ),
          
          const SizedBox(width: 16),
          
          // Timestamp
          Text(
            timeFormat.format(log.timestamp),
            style: const TextStyle(
              fontSize: 11,
              color: Color(0xFF666666),
            ),
          ),
        ],
      ),
    );
  }

  String _getPhaseLabel(ExecutionPhase phase) {
    switch (phase) {
      case ExecutionPhase.intentAnalysis:
        return 'INTENT_ANALYSIS';
      case ExecutionPhase.projectContext:
        return 'PROJECT_CONTEXT';
      case ExecutionPhase.fileIndex:
        return 'FILE_INDEX';
      case ExecutionPhase.riskAnalysis:
        return 'RISK_ANALYSIS';
      case ExecutionPhase.implementationPlan:
        return 'IMPLEMENTATION_PLAN';
      case ExecutionPhase.codeGeneration:
        return 'CODE_GENERATION';
      case ExecutionPhase.validation:
        return 'VALIDATION';
      case ExecutionPhase.testResults:
        return 'TEST_RESULTS';
      case ExecutionPhase.confidence:
        return 'CONFIDENCE';
      case ExecutionPhase.complete:
        return 'COMPLETE';
    }
  }

  Color _getPhaseColor(ExecutionPhase phase) {
    switch (phase) {
      case ExecutionPhase.intentAnalysis:
      case ExecutionPhase.projectContext:
        return const Color(0xFF00d4ff);
      case ExecutionPhase.fileIndex:
      case ExecutionPhase.riskAnalysis:
        return const Color(0xFFffd93d);
      case ExecutionPhase.implementationPlan:
      case ExecutionPhase.codeGeneration:
        return const Color(0xFF00ff9d);
      case ExecutionPhase.validation:
      case ExecutionPhase.testResults:
        return const Color(0xFFa78bfa);
      case ExecutionPhase.confidence:
      case ExecutionPhase.complete:
        return const Color(0xFF00ff9d);
    }
  }
}
