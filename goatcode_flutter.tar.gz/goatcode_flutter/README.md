# GOATCODE Flutter - Production Agent System

Complete, fully functional Flutter application for GOATCODE - a deterministic, production-grade coding agent with real architecture.

## ⚡ Features

- **🎯 Real Agent Control**: Execute coding tasks with full lifecycle management
- **📊 Live Metrics Dashboard**: Real-time token budget, file indexing, and test results
- **🏗️ Architecture Visualization**: View all system components
- **📈 Tool Statistics**: Monitor tool usage and performance
- **🔄 Real-time Updates**: WebSocket integration for live execution logs
- **💾 State Management**: Riverpod for robust state handling
- **🎨 Premium UI**: Dark theme with cyberpunk aesthetics

## 🚀 Quick Start

### Prerequisites

- Flutter SDK (>=3.0.0)
- Dart SDK (>=3.0.0)

### Installation

1. **Navigate to project directory:**
```bash
cd goatcode_flutter
```

2. **Install dependencies:**
```bash
flutter pub get
```

3. **Generate model files:**
```bash
flutter pub run build_runner build --delete-conflicting-outputs
```

4. **Run the app:**
```bash
flutter run
```

For web:
```bash
flutter run -d chrome
```

For desktop:
```bash
flutter run -d macos  # or windows, linux
```

## 📁 Project Structure

```
lib/
├── main.dart                          # App entry point
├── models/
│   └── models.dart                    # Data models (tasks, metrics, etc.)
├── screens/
│   ├── home_screen.dart              # Main screen with tabs
│   ├── agent_control_screen.dart     # Task execution screen
│   ├── architecture_screen.dart      # Architecture components
│   ├── tools_stats_screen.dart       # Tool statistics
│   └── metrics_screen.dart           # Performance metrics
├── services/
│   ├── api_service.dart              # API/backend service
│   └── providers.dart                # Riverpod state providers
└── widgets/
    ├── metric_card.dart              # Reusable metric card
    └── execution_log_widget.dart     # Log display widget
```

## 🎯 Core Architecture (The 80%)

The app demonstrates the real architecture that beats prompt-only agents:

### 1. File Indexing Engine
- AST-based semantic code search
- FAISS vector embeddings
- Incremental indexing with Redis cache

### 2. Context Injection
- Automatic relevance-based context retrieval
- Token budget optimization
- Semantic reranking

### 3. Test→Fix→Retry Loop
- Iterative compilation with error recovery
- Automated test execution
- Intelligent fix generation

### 4. Diff-Based Patching
- AST-aware minimal diffs
- No full file rewrites
- Surgical code edits

### 5. Token Budget Manager
- Dynamic context window optimization
- Sliding window strategy
- Real-time budget monitoring

### 6. Memory Patterns
- Resolution pattern storage
- Vector DB for pattern retrieval
- Continuous learning

## 🔧 Configuration

### Switching to Real API

The app currently uses a **Mock Service** for demo purposes. To connect to a real GOATCODE backend:

1. Open `lib/services/providers.dart`
2. Replace:
```dart
final apiServiceProvider = Provider<MockGoatCodeService>((ref) {
  return MockGoatCodeService();
});
```

With:
```dart
final apiServiceProvider = Provider<GoatCodeApiService>((ref) {
  return GoatCodeApiService(
    baseUrl: 'YOUR_API_URL', // e.g., 'https://api.goatcode.dev'
  );
});
```

## 📊 State Management

Uses **Riverpod** for:
- Clean dependency injection
- Reactive state updates
- Type-safe providers
- Automatic disposal

### Key Providers

```dart
// Current task execution
currentTaskProvider

// Project list
projectsProvider

// Real-time execution logs
executionLogsProvider

// Tool statistics
toolStatsProvider

// Architecture components
architectureComponentsProvider
```

## 🎨 UI Components

### Screens
1. **Agent Control**: Task creation and execution monitoring
2. **Architecture**: System component visualization
3. **Tool Stats**: Performance metrics for each tool
4. **Metrics**: High-level system performance

### Theme
- **Primary**: Electric Green (#00ff9d)
- **Secondary**: Cyan (#00d4ff)
- **Background**: Dark gradients
- **Typography**: JetBrains Mono

## 🔌 API Integration

### Endpoints

```dart
POST   /v1/tasks           // Create task
GET    /v1/tasks/:id       // Get task status
GET    /v1/tasks           // Task history
WS     /v1/tasks/:id/stream // Real-time updates

GET    /v1/projects        // List projects
POST   /v1/projects        // Create project
POST   /v1/projects/:id/index // Index project

GET    /v1/stats/tools     // Tool statistics
GET    /v1/architecture/components // Components info
```

## 🧪 Development Mode

The app includes a **MockGoatCodeService** that simulates:
- Task execution with realistic delays
- Progressive log streaming
- Metrics updates
- Generated code output

Perfect for:
- Frontend development
- UI/UX testing
- Demo purposes
- Offline development

## 📦 Dependencies

### Core
- `flutter_riverpod` - State management
- `dio` - HTTP client
- `web_socket_channel` - Real-time updates

### UI
- `google_fonts` - JetBrains Mono
- `lucide_icons` - Icon set
- `flutter_animate` - Animations

### Storage
- `hive` - Local database
- `shared_preferences` - Settings

### Utilities
- `intl` - Date formatting
- `uuid` - ID generation
- `json_annotation` - Serialization

## 🚢 Production Deployment

### Web
```bash
flutter build web --release
```

### Mobile
```bash
# iOS
flutter build ipa --release

# Android
flutter build apk --release
flutter build appbundle --release
```

### Desktop
```bash
# macOS
flutter build macos --release

# Windows
flutter build windows --release

# Linux
flutter build linux --release
```

## 🎯 Next Steps

1. **Backend Integration**
   - Deploy GOATCODE backend (see architecture.md)
   - Configure API endpoints
   - Set up WebSocket server

2. **Enhanced Features**
   - Code diff visualization
   - Test result details
   - Project management UI
   - History and analytics

3. **Performance**
   - Lazy loading for large logs
   - Virtual scrolling
   - Image optimization
   - Cache strategies

## 📝 License

This is a demonstration of production-grade agent architecture.

## 🤝 Contributing

This is a complete, working reference implementation showcasing:
- Modern Flutter architecture
- Clean code principles
- Production-ready patterns
- Real-world state management

Use it as a foundation for building serious agent UIs.

---

**Built with Flutter 💙 for serious software engineering 🚀**
